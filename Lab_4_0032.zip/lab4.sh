#!/bin/bash

while true
do
echo "----- FILE OPERATIONS MENU -----"
echo "1. Create File"
echo "2. Copy File"
echo "3. Move/Rename File"
echo "4. Delete File"
echo "5. Display File Content"
echo "6. Exit"
echo "--------------------------------"

read -p "Enter your choice: " choice

case $choice in

1)
read -p "Enter file name to create: " fname
if [ -f "$fname" ]; then
    echo "Error: File already exists!"
else
    read -p "Enter content: " content
    echo "$content" > "$fname"
    echo "File '$fname' created successfully."
fi
;;

2)
read -p "Enter source filename: " source
read -p "Enter destination filename: " dest

if [ -f "$source" ]; then
    cp "$source" "$dest"
    echo "File copied successfully."
else
    echo "Error: Source file does not exist!"
fi
;;

3)
read -p "Enter filename to move/rename: " source
read -p "Enter new filename: " dest

if [ -f "$source" ]; then
    mv "$source" "$dest"
    echo "File moved/renamed successfully."
else
    echo "Error: File does not exist!"
fi
;;

4)
read -p "Enter filename to delete: " fname

if [ -f "$fname" ]; then
    rm "$fname"
    echo "File deleted successfully."
else
    echo "Error: File does not exist!"
fi
;;

5)
read -p "Enter filename to display: " fname

if [ -f "$fname" ]; then
    echo "Content of '$fname':"
    cat "$fname"
else
    echo "Error: File does not exist!"
fi
;;

6)
echo "Exiting program..."
exit
;;

*)
echo "Invalid choice! Please enter a number between 1 and 6."
;;

esac

echo ""
done
